﻿namespace Library.Data.Seeding.Data
{
    public class UserSeedData
    {
        public const string Password = "123456";

        public const string User1Email = "user1@library.bg";

        public const string User2Email = "user2@library.bg";
    }
}
