﻿namespace Library.Areas.Admin
{
    public class AdminConstants
    {
        public const string AdminAreaName = "Admin";

        public const string AdminRoleName = "Admin";
    }
}
