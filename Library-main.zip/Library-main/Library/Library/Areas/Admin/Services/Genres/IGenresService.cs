﻿namespace Library.Areas.Admin.Services.Genres
{
    public interface IGenresService
    {
        bool AddGenreAndReturnBoolean(string name);
    }
}
