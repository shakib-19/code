﻿namespace Library.Areas.User
{
    public class UserConstants
    {
        public const string UserAreaName = "User";

        public const string UserRoleName = "User";
    }
}
