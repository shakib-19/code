﻿namespace Library.Services.Books.Models
{
    public class GenreServiceModel
    {
        public string Id { get; init; }

        public string Name { get; init; }
    }
}
