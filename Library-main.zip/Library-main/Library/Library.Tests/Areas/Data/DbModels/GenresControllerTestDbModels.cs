﻿namespace Library.Tests.Areas.Data.DbModels
{
    using Library.Areas.Admin.Services.Genres.Models;

    public class GenresControllerTestDbModels
    {
        public static AddGenreFormModel AddGenreModel = new()
        {
            Name = "New Genre Test Name"
        };
    }
}
